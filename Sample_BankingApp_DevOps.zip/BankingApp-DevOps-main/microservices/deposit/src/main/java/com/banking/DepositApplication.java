package com.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class DepositApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(DepositApplication.class, args);
	}

	@org.springframework.web.bind.annotation.CrossOrigin(origins = "*")
	@org.springframework.web.bind.annotation.RestController
	public static class DepositController {
		@org.springframework.web.bind.annotation.GetMapping("/deposit")
		public String deposit() {
			return "Deposit service is called";
		}
	}

}
