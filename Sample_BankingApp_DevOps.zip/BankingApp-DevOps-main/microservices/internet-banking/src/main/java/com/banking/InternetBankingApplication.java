package com.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class InternetBankingApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(InternetBankingApplication.class, args);
	}

	@org.springframework.web.bind.annotation.CrossOrigin(origins = "*")
	@org.springframework.web.bind.annotation.RestController
	public static class InternetBankingController {
		@org.springframework.web.bind.annotation.GetMapping("/internet-banking")
		public String internetBanking() {
			return "Internet Banking service is called";
		}
	}

}
