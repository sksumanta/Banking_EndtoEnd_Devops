package com.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class CustomerCareApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(CustomerCareApplication.class, args);
	}

	@org.springframework.web.bind.annotation.CrossOrigin(origins = "*")
	@org.springframework.web.bind.annotation.RestController
	public static class CustomerCareController {
		@org.springframework.web.bind.annotation.GetMapping("/customer-care")
		public String customerCare() {
			return "Customer Care service is called";
		}
	}

}
