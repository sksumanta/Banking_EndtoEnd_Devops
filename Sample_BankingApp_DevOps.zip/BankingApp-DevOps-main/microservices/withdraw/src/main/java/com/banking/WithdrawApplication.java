package com.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class WithdrawApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(WithdrawApplication.class, args);
	}

	@org.springframework.web.bind.annotation.CrossOrigin(origins = "*")
	@org.springframework.web.bind.annotation.RestController
	public static class WithdrawController {
		@org.springframework.web.bind.annotation.GetMapping("/withdraw")
		public String withdraw() {
			return "Withdraw service is called";
		}
	}

}
